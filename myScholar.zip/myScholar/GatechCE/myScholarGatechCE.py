import requests
import re
import pdb
#from HTMLParser import HTMLParser
from bs4 import BeautifulSoup
import json
pictag={"td": ('class','views-field-field-profile-picture')}

taglist=['','','','']
attrlist=['row faculty-row','']

class scholar:
    def __init__(self):
        self.name=""
        self.email=""
        self.url=""
        self.pic=""



#urllist=['','']

#for url in urllist:
#url="https://www.ece.gatech.edu/faculty-staff-directory?field_group_filter_value=1"
imgdir="gatech/ce/"
url="http://www.ce.gatech.edu/people?field_person_subgroup_value=faculty&field_person_department_value=All&field_person_department_value_1=All&field_person_last_name_value_1=All"
base="http://www.ce.gatech.edu"
#commonUrl="https://www.ece.gatech.edu/faculty-staff-directory/"
urltext=requests.get(url)
#pdb.set_trace()
soup=BeautifulSoup(urltext.text,"html5lib")
scholars={}
rawInfo=soup.tbody.findAll('span',attrs={"class":'person_image_main'})
#pdb.set_trace()

for ele in rawInfo:
    #pdb.set_trace()
    info_personalurl=base+ele.a["href"]
    subhtml=requests.get(base+ele.a["href"])
    subbf=BeautifulSoup(subhtml.text,"html5lib")
    #info=subbf.find("div",attrs={"class":"view view-person-faculty-details view-id-person_faculty_details view-display-id-page_1 view-dom-id-0c972949f075fb3dac1c210e365b191b"})
    info=subbf.find("div",attrs={"class":re.compile("^view view-person-faculty-details.+")})
    info_img=requests.get(info.img["src"])
    info_name=info.h3.string.encode('utf8')
    info_title=info.h5.string.encode('utf8')
    info_email=""
    info_email=info.find("a",attrs={"href":re.compile("^mailto:[a-zA-Z0-9]+\.?[a-zA-Z0-9]*@.*\.?gatech.edu")})
    if info_email:
        info_email=info_email.string.encode("utf8")
    info_tel=""

    #pdb.set_trace()
    for i in info.findAll("h6"):
    #pdb.set_trace()
	if i.string:
	    temp=re.match("^\d+.{1}\d+.{1}\d+",i.string)
            if temp:
                info_tel=temp.group(0)
	        break
    
    temp_personalurl=info.find("a",attrs={"href":re.compile("^http:/{2}.+")})
    if temp_personalurl:
        info_personalurl=temp_personalurl.string.encode('utf8')
    if info_email:
        with open(info_email+'.jpg', 'wb') as imghandle:
            for block in info_img.iter_content(1024):
                imghandle.write(block)
    #pdb.set_trace()
        scholars[info_email]=[info_name,info_title,info_tel]
    
with open("ce.gatech.json",'w') as infohandle:
    json.dump(scholars,infohandle)
print "Got it!"

