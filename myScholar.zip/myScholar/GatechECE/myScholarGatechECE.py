import requests
import re
import pdb
#from HTMLParser import HTMLParser
from bs4 import BeautifulSoup
import json
pictag={"td": ('class','views-field-field-profile-picture')}

taglist=['','','','']
attrlist=['row faculty-row','']

#urllist=['','']

#for url in urllist:
#url="https://www.ece.gatech.edu/faculty-staff-directory?field_group_filter_value=1"
imgdir="gatech/ce/"
url="https://www.ece.gatech.edu/faculty-staff-directory?field_group_filter_value=1"
base="https://www.ece.gatech.edu"
#commonUrl="https://www.ece.gatech.edu/faculty-staff-directory/"
urltext=requests.get(url)
#pdb.set_trace()
soup=BeautifulSoup(urltext.text,"html5lib")
scholars={}
rawInfo=soup.findAll('div',attrs={"class":'faculty-staff-information'})
#pdb.set_trace()

for ele in rawInfo:    
    #pdb.set_trace()
    info_personalurl=base+ele.a["href"]
    info_name=ele.a.string.encode('utf8')
    subhtml=requests.get(base+ele.a["href"])
    subbf=BeautifulSoup(subhtml.text,"html5lib")
    
    info=subbf.find("div",attrs={"class":re.compile("^personnel-information row")})
    info_img=requests.get(info.img["src"])   
    
    info_title=info.find("div",attrs={"class":"titles"}).find("div",attrs={"class":"field-item even"}).string.encode("utf8")
    info_email=""
    info_email=info.find("a",attrs={"href":re.compile("^mailto:[a-zA-Z0-9]+\.?[a-zA-Z0-9]*@.*\.?gatech.edu")})

    if info_email:
        info_email=info_email["href"][7:].encode("utf8")
    info_tel="None"

    #pdb.set_trace()
    info_tel=info.find("div",attrs={"class":"contact-phone"})
    if info_tel:
        info_tel=info_tel.find("div",attrs={"class":"field-item even"}).string.encode("utf8")
    temp_personalurl="None"
    temp_personalurl=info.find("a",attrs={"href":re.compile("^http:/{2}.+")})
    if temp_personalurl:
        info_personalurl=temp_personalurl["href"].encode('utf8')
    bio=subbf.find("div", attrs={"id":"overview"})
    #pdb.set_trace()
    info_bio=""
    if bio:
        t_bio=bio.findAll("p")
        for x in t_bio:
            if x:
              info_bio=info_bio+x.encode("utf8")
        #pdb.set_trace()
        #for x in t_bio:
        #    if x:
        #        info_bio=info_bio+x.string.encode("utf8") 
    if info_email:
        with open(info_email+'.jpg', 'wb') as imghandle:
            for block in info_img.iter_content(1024):
                imghandle.write(block)
    #pdb.set_trace()
        scholars[info_email]=[info_name,info_title,info_tel,info_bio,"School of Electrical and Computer Engineering"]
    
with open("ece.gatech.json",'w') as infohandle:
    json.dump(scholars,infohandle)
print "Got it!"

